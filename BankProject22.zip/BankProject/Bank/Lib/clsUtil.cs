﻿using System;

namespace BankCore.Lib
{
    public static class clsUtil
    {
        // ======== Encryption / Decryption ========
        // دوال التشفير وفك التشفير

        // Simple character-based encryption using key shift
        // تشفير بسيط يعتمد على تحريك الأحرف باستخدام مفتاح
        public static string EncryptText(string text, short key = 2)
        {
            if (string.IsNullOrEmpty(text))
                return text;

            char[] chars = text.ToCharArray();

            for (int i = 0; i < chars.Length; i++)
                chars[i] = (char)(chars[i] + key);

            return new string(chars);
        }

        // Reverse operation of EncryptText
        // فك التشفير باستخدام نفس المفتاح
        public static string DecryptText(string text, short key = 2)
        {
            if (string.IsNullOrEmpty(text))
                return text;

            char[] chars = text.ToCharArray();

            for (int i = 0; i < chars.Length; i++)
                chars[i] = (char)(chars[i] - key);

            return new string(chars);
        }
    }
}